/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { LeftSidebar } from './components/LeftSidebar';
import { BreakingNews } from './components/BreakingNews';
import { DailyFeed } from './components/DailyFeed';
import { FeaturedStories } from './components/FeaturedStories';
import { Footer } from './components/Footer';
import { ArticleModal } from './components/ArticleModal';
import { SearchModal } from './components/SearchModal';
import { ContactModal, ShowcaseModal } from './components/InfoModals';
import { AdModal } from './components/AdModal';
import { ImageLightboxModal } from './components/ImageLightboxModal';
import { FloatingControls } from './components/FloatingControls';
import { AdminPanel } from './components/admin/AdminPanel';
import { ReaderAccountModal } from './components/ReaderAccountModal';
import { ARTICLES, Article, getLocalizedArticle } from './data/newspaperData';
import { Language, TRANSLATIONS, CATEGORY_TRANSLATIONS } from './data/translations';
import { useNewsroomData, mapAdminArticleToPublic } from './services/bridgeData';
import { NewsroomStore } from './services/adminStore';
import { ReaderUser } from './types/admin';
import { X, Filter, Flame } from 'lucide-react';

function checkIsAdminRoute(): boolean {
  if (typeof window === 'undefined') return false;
  const path = window.location.pathname.toLowerCase();
  const hash = window.location.hash.toLowerCase();
  return (
    path.startsWith('/admin') ||
    path === '/login' ||
    path === '/register' ||
    hash === '#admin' ||
    hash.startsWith('#/admin') ||
    hash.startsWith('#/login') ||
    hash.startsWith('#/register')
  );
}

export default function App() {
  const [language, setLanguage] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('newspaper_lang');
      return saved === 'si' ? 'si' : 'en';
    } catch {
      return 'en';
    }
  });

  // Newsroom Live Dynamic Store Data
  const { publicArticles, breakingNews, settings, currentUser } = useNewsroomData();

  // Admin CMS Open State (checks both pathname /admin and #admin in URL)
  const [isAdminOpen, setIsAdminOpen] = useState<boolean>(() => {
    return checkIsAdminRoute();
  });

  // Reader account modal state and subscribed reader
  const [isReaderAccountOpen, setIsReaderAccountOpen] = useState(false);
  const [currentReader, setCurrentReader] = useState<ReaderUser | null>(() => NewsroomStore.getCurrentReader());

  // Public Reader UI states
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('ALL');
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [isAdOpen, setIsAdOpen] = useState(false);
  const [lightboxInfo, setLightboxInfo] = useState<{
    isOpen: boolean;
    imageUrl: string;
    title: string;
    caption?: string;
  }>({
    isOpen: false,
    imageUrl: '',
    title: '',
  });
  const [showcaseInfo, setShowcaseInfo] = useState<{
    isOpen: boolean;
    title: string;
    type: 'shortcodes' | 'post_types';
  }>({
    isOpen: false,
    title: '',
    type: 'shortcodes',
  });

  const t = TRANSLATIONS[language];

  const openAdmin = () => {
    setIsAdminOpen(true);
    try {
      if (window.location.pathname !== '/admin') {
        window.history.pushState(null, '', '/admin');
      }
    } catch {
      // fallback
    }
    if (!window.location.hash.startsWith('#/admin')) {
      window.location.hash = '#/admin';
    }
  };

  const closeAdmin = () => {
    setIsAdminOpen(false);
    try {
      if (window.location.pathname.startsWith('/admin')) {
        window.history.pushState(null, '', '/');
      }
    } catch {
      // fallback
    }
    if (window.location.hash.startsWith('#/admin') || window.location.hash === '#admin') {
      window.location.hash = '';
    }
  };

  // Sync reader store updates
  useEffect(() => {
    const unsubscribe = NewsroomStore.subscribe(() => {
      setCurrentReader(NewsroomStore.getCurrentReader());
    });
    return unsubscribe;
  }, []);

  // Sync URL changes (popstate & hashchange)
  useEffect(() => {
    const handleRouteChange = () => {
      setIsAdminOpen(checkIsAdminRoute());
    };
    window.addEventListener('popstate', handleRouteChange);
    window.addEventListener('hashchange', handleRouteChange);
    return () => {
      window.removeEventListener('popstate', handleRouteChange);
      window.removeEventListener('hashchange', handleRouteChange);
    };
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem('newspaper_lang', language);
    } catch {
      // ignore
    }
    document.documentElement.lang = language;
  }, [language]);

  // Merge dynamic newsroom store articles with default mock articles
  const combinedArticles: Article[] = [
    ...publicArticles,
    ...ARTICLES.filter((a) => !publicArticles.some((p) => p.id === a.id)),
  ];

  // Filter articles based on active category / tag
  const filteredArticles = combinedArticles.filter((article) => {
    if (activeCategory !== 'ALL') {
      const matchCat =
        article.category.toUpperCase() === activeCategory.toUpperCase() ||
        (article.categorySecondary &&
          article.categorySecondary.toUpperCase() === activeCategory.toUpperCase());
      if (!matchCat) return false;
    }
    if (activeTag) {
      const matchTag =
        article.tags?.some(
          (tg) => tg.toLowerCase() === activeTag.toLowerCase()
        ) ||
        article.tagsSi?.some(
          (tg) => tg.toLowerCase() === activeTag.toLowerCase()
        );
      if (!matchTag) return false;
    }
    return true;
  });

  // Article selection helper supporting English & Sinhala title matching
  const handleSelectArticleByTitle = (title: string) => {
    const found = combinedArticles.find((a) =>
      a.title.toLowerCase().includes(title.toLowerCase()) ||
      (a.titleSi && a.titleSi.toLowerCase().includes(title.toLowerCase()))
    );
    if (found) {
      handleOpenArticleModal(found);
    } else {
      const tempArticle: Article = {
        id: 'latest-' + encodeURIComponent(title.slice(0, 15)),
        title: title,
        titleSi: title,
        category: 'EDITORIAL',
        categorySi: 'කතුවැකිය',
        date: 'SEPTEMBER 25, 2017',
        dateSi: '2017 සැප්තැම්බර් 25',
        author: 'CMSMASTERS',
        authorSi: 'සී.එම්.එස් මාස්ටර්ස්',
        commentsCount: 2,
        excerpt:
          language === 'si'
            ? 'මෙම කාලීන තේමාව පිළිබඳව අපගේ විශේෂාංග ලේඛක මඬුල්ල විසින් සම්පාදිත ගැඹුරු විග්‍රහයක්.'
            : 'Etiam eu molestie eros, commodo nec turpis hendrerit sapien. Maecenas tempus leo ac nisi iaculis porta. Sed sapien tempus.',
        content:
          language === 'si'
            ? [
                `නවතම සංස්කෘතික සහ සමාජයීය වර්ධනයන් පිළිබඳ විමර්ශනය: "${title}". අපගේ සංස්කාරක මණ්ඩලය විසින් නිරීක්ෂණය කරන ලද කරුණු රැසක් මෙහි අන්තර්ගත වේ.`,
                'සමාජයේ විවිධ ක්ෂේත්‍රයන්හි සිදුවන ශීඝ්‍ර පරිවර්තනයන් ජනජීවිතය කෙරෙහි ඍජු බලපෑමක් ඇති කර තිබේ.',
              ]
            : [
                `Exploring the latest culinary and cultural developments: "${title}". Curabitur vel feugiat massa, sed facilisis ligula. Duis eleifend nunc sit amet mi dapibus ornare.`,
                'Suspendisse non tempus vel libero sem pellentesque ornare amet. In hac habitasse platea dictumst.',
              ],
        readTime: language === 'si' ? 'මිනිත්තු 3 ක කියවීමක්' : '3 min read',
      };
      handleOpenArticleModal(tempArticle);
    }
  };

  const handleOpenArticleModal = (article: Article) => {
    setSelectedArticle(article);
    NewsroomStore.incrementArticleViews(article.id);
  };

  const handleSelectTag = (tag: string) => {
    setActiveTag(tag);
    window.scrollTo({ top: 180, behavior: 'smooth' });
  };

  const handleCategorySelect = (cat: string) => {
    setActiveCategory(cat);
    setActiveTag(null);
    window.scrollTo({ top: 180, behavior: 'smooth' });
  };

  const handleScrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Popular articles sorted for sidebar
  const popularArticles = [...combinedArticles].sort(
    (a, b) => (a.popularRank || 99) - (b.popularRank || 99)
  );

  const displayCategoryName =
    language === 'si' && CATEGORY_TRANSLATIONS[activeCategory.toUpperCase()]
      ? CATEGORY_TRANSLATIONS[activeCategory.toUpperCase()]
      : activeCategory;

  // IF ADMIN PANEL IS OPEN, RENDER CMS BACKEND VIEW
  if (isAdminOpen) {
    return (
      <AdminPanel
        onReturnToPublic={closeAdmin}
        onPreviewArticleInPublic={(adminArt) => {
          closeAdmin();
          const mapped = mapAdminArticleToPublic(adminArt, true);
          handleOpenArticleModal(mapped);
        }}
      />
    );
  }

  // PUBLIC NEWSPAPER READER VIEW
  return (
    <div className="min-h-screen flex flex-col bg-[#faf6ee] text-[#241c13]">
      {/* Header with utility bar, masthead, main navigation, Language Switcher, Reader Account & Newsroom CMS Button */}
      <Header
        currentCategory={activeCategory}
        language={language}
        onToggleLanguage={(lang) => setLanguage(lang)}
        onSelectCategory={handleCategorySelect}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenContact={() => setIsContactOpen(true)}
        onOpenShortcodes={() =>
          setShowcaseInfo({
            isOpen: true,
            title: language === 'si' ? 'කෙටි කේත සංග්‍රහය' : 'Editorial Shortcodes Showcase',
            type: 'shortcodes',
          })
        }
        onOpenPostTypes={() =>
          setShowcaseInfo({
            isOpen: true,
            title: language === 'si' ? 'පුවත් ආකෘති සංග්‍රහය' : 'Post Types & Formats Showcase',
            type: 'post_types',
          })
        }
        onOpenAdmin={openAdmin}
        onOpenReaderAccount={() => setIsReaderAccountOpen(true)}
        adminUser={currentUser ? { name: currentUser.name, role: currentUser.role } : null}
        readerUser={
          currentReader
            ? {
                name: currentReader.name,
                email: currentReader.email,
                bookmarksCount: currentReader.bookmarks?.length || 0,
              }
            : null
        }
      />

      {/* Dynamic Sitewide Breaking News Ticker Bar (configured from Admin) */}
      {settings.layout.showBreakingTicker && breakingNews.length > 0 && (
        <div className="w-full bg-[#b91c1c] text-white border-b border-[#991b1b] shadow-xs select-none">
          <div className="max-w-[1180px] mx-auto px-4 sm:px-6 h-8 flex items-center gap-3 overflow-hidden text-xs">
            <span className="flex items-center gap-1.5 font-mono uppercase font-black tracking-widest text-[10px] bg-black/40 px-2 py-0.5 rounded-xs shrink-0">
              <Flame className="w-3.5 h-3.5 text-yellow-300 animate-pulse" />
              {t.breakingNewsTitle}
            </span>
            <div className="truncate flex-1 font-serif text-[11px] sm:text-xs">
              {breakingNews.map((item, idx) => (
                <span key={item.id} className="mr-6">
                  {idx > 0 && <span className="opacity-40 mr-6">✦</span>}
                  {language === 'si' && item.headlineSi ? item.headlineSi : item.headline}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-[1180px] w-full mx-auto px-4 sm:px-6 pt-7">
        {/* Active Filter Badge Bar */}
        {(activeCategory !== 'ALL' || activeTag) && (
          <div className="mb-6 p-3 bg-[#f4ebdc] border border-[#dfcead] flex items-center justify-between text-xs font-sans rounded-xs shadow-xs relative overflow-hidden">
            <div className="absolute top-0 left-0 bottom-0 w-1 bg-[#facc15]" />
            <div className="flex items-center space-x-2 pl-2">
              <Filter className="w-3.5 h-3.5 text-[#d97706]" />
              <span className="text-[#695333] font-medium">{t.filteredView}</span>
              {activeCategory !== 'ALL' && (
                <span className="font-extrabold bg-[#fef08a] text-[#1b1712] px-2 py-0.5 border border-[#fde047] rounded-xs">
                  {t.categoryLabel}: {displayCategoryName}
                </span>
              )}
              {activeTag && (
                <span className="font-extrabold bg-[#fef08a] text-[#1b1712] px-2 py-0.5 border border-[#fde047] rounded-xs">
                  {t.tagLabel}: #{activeTag}
                </span>
              )}
            </div>
            <button
              onClick={() => {
                setActiveCategory('ALL');
                setActiveTag(null);
              }}
              className="text-[#856535] hover:text-[#241c13] hover:underline flex items-center space-x-1 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
              <span>{t.clearFilter}</span>
            </button>
          </div>
        )}

        {/* 3-Column Newspaper Top Section: Breaking News (Hero lead story), Left column (Side dispatches), Daily feed (Timeline) */}
        <div className="flex flex-col lg:grid lg:grid-cols-12 gap-8 lg:gap-0">
          {/* Middle Column / Hero: Order 1 on mobile, Order 2 on desktop */}
          <div className="order-1 lg:order-2 lg:col-span-6">
            <BreakingNews
              articles={
                filteredArticles.length > 0
                  ? filteredArticles
                  : combinedArticles.filter((a) => a.isBreaking)
              }
              language={language}
              onSelectArticle={handleOpenArticleModal}
              onOpenLightbox={(imageUrl, title, caption) =>
                setLightboxInfo({ isOpen: true, imageUrl, title, caption })
              }
            />
          </div>

          {/* Left Column: Order 2 on mobile, Order 1 on desktop */}
          <div className="order-2 lg:order-1 lg:col-span-3">
            <LeftSidebar
              popularArticles={popularArticles}
              language={language}
              onSelectArticle={handleOpenArticleModal}
              onSelectTitle={handleSelectArticleByTitle}
              onSelectTag={handleSelectTag}
              onOpenAd={() => setIsAdOpen(true)}
              onOpenImage={(imageUrl, title, caption) =>
                setLightboxInfo({ isOpen: true, imageUrl, title, caption })
              }
            />
          </div>

          {/* Right Column (Daily Feed): Order 3 on mobile and desktop */}
          <div className="order-3 lg:order-3 lg:col-span-3 lg:pl-6">
            <DailyFeed
              articles={
                filteredArticles.length > 0
                  ? filteredArticles
                  : combinedArticles.filter((a) => a.isDailyFeed || !a.isHero)
              }
              language={language}
              onSelectArticle={handleOpenArticleModal}
              onViewMore={() => {
                window.scrollTo({ top: 800, behavior: 'smooth' });
              }}
            />
          </div>
        </div>

        {/* Featured Stories 6-Card Grid & Newsletter */}
        <FeaturedStories
          articles={combinedArticles}
          language={language}
          onSelectArticle={handleOpenArticleModal}
          onViewMore={() => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          onOpenLightbox={(imageUrl, title, caption) =>
            setLightboxInfo({ isOpen: true, imageUrl, title, caption })
          }
        />
      </main>

      {/* Footer */}
      <Footer
        language={language}
        onSelectCategory={handleCategorySelect}
        onSelectTag={handleSelectTag}
        onOpenContact={() => setIsContactOpen(true)}
      />

      {/* Floating Controls with quick Newsroom Admin trigger */}
      <FloatingControls
        onScrollToTop={handleScrollToTop}
        onOpenAdmin={openAdmin}
      />

      {/* Reader Profile & Bookmarks Modal */}
      <ReaderAccountModal
        isOpen={isReaderAccountOpen}
        onClose={() => setIsReaderAccountOpen(false)}
        onOpenArticle={handleOpenArticleModal}
        onOpenAdmin={openAdmin}
        language={language}
      />

      {/* Article Reader Modal */}
      <ArticleModal
        article={selectedArticle}
        language={language}
        onClose={() => setSelectedArticle(null)}
        onSelectTag={handleSelectTag}
        onOpenImageLightbox={(imageUrl, title, caption) =>
          setLightboxInfo({ isOpen: true, imageUrl, title, caption })
        }
      />

      {/* Image Lightbox Viewer Modal */}
      <ImageLightboxModal
        isOpen={lightboxInfo.isOpen}
        onClose={() =>
          setLightboxInfo((prev) => ({ ...prev, isOpen: false }))
        }
        imageUrl={lightboxInfo.imageUrl}
        title={lightboxInfo.title}
        caption={lightboxInfo.caption}
        onOpenArticle={
          selectedArticle
            ? undefined
            : () => {
                const found = combinedArticles.find(
                  (a) => a.imageUrl === lightboxInfo.imageUrl
                );
                if (found) handleOpenArticleModal(found);
              }
        }
      />

      {/* Linked Advertisement / Sponsor Modal */}
      <AdModal
        isOpen={isAdOpen}
        language={language}
        onClose={() => setIsAdOpen(false)}
      />

      {/* Live Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        language={language}
        onClose={() => setIsSearchOpen(false)}
        articles={combinedArticles}
        onSelectArticle={handleOpenArticleModal}
      />

      {/* Contact Modal */}
      <ContactModal
        isOpen={isContactOpen}
        language={language}
        onClose={() => setIsContactOpen(false)}
      />

      {/* Shortcodes & Post Types Showcase Modal */}
      <ShowcaseModal
        isOpen={showcaseInfo.isOpen}
        onClose={() =>
          setShowcaseInfo((prev) => ({ ...prev, isOpen: false }))
        }
        title={showcaseInfo.title}
        type={showcaseInfo.type}
      />
    </div>
  );
}
