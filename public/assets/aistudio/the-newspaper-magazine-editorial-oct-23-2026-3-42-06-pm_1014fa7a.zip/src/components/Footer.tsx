import React from 'react';
import { FOOTER_LINKS } from '../data/newspaperData';
import { Language, TRANSLATIONS, FOOTER_LINKS_SI } from '../data/translations';

interface FooterProps {
  language: Language;
  onSelectCategory: (category: string) => void;
  onSelectTag: (tag: string) => void;
  onOpenContact: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  language,
  onSelectCategory,
  onSelectTag,
  onOpenContact,
}) => {
  const t = TRANSLATIONS[language];
  const links = language === 'si' ? FOOTER_LINKS_SI : FOOTER_LINKS;

  return (
    <footer className="w-full bg-[#f4ebd9] select-none border-t border-[#dfcead]">
      {/* Bright Yellow Editorial Stripe & Thick Rule */}
      <div className="w-full h-[3px] bg-[#facc15]" />
      <div className="w-full border-t-2 border-[#2b2014]" />

      <div className="max-w-[1180px] mx-auto px-4 sm:px-6 pt-10 pb-8">
        {/* 4 Columns */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          {/* Col 1: Brand & Reader links */}
          <div>
            <div className="mb-4">
              <span className="font-serif italic text-sm text-[#8a7251] block leading-none">
                {language === 'si' ? '' : 'The'}
              </span>
              <span className="font-masthead font-extrabold text-[20px] tracking-tight text-[#1b1712] block leading-tight">
                {t.siteTitle}
              </span>
            </div>

            <ul className="space-y-1.5 text-[12px] font-serif text-[#5e4e3a]">
              {links.reader.map((item, idx) => (
                <li key={idx}>
                  <button
                    onClick={() => {
                      if (
                        item.toLowerCase().includes('contact') ||
                        item.includes('සබඳතා')
                      ) {
                        onOpenContact();
                      } else {
                        onSelectCategory('ALL');
                      }
                    }}
                    className="hover:text-[#d97706] hover:underline cursor-pointer transition-colors text-left"
                  >
                    {item}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 2: NEWS */}
          <div>
            <h4 className="text-[11px] font-bold tracking-[0.08em] uppercase text-[#261f16] font-sans mb-3.5">
              {t.footerNewsTitle}
            </h4>
            <ul className="space-y-1.5 text-[12px] font-serif text-[#5e4e3a]">
              {links.news.map((item, idx) => (
                <li key={idx}>
                  <button
                    onClick={() => {
                      // Map common categories or fallback to ALL
                      onSelectCategory('ALL');
                    }}
                    className="hover:text-[#d97706] hover:underline cursor-pointer transition-colors text-left"
                  >
                    {item}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: OPINION */}
          <div>
            <h4 className="text-[11px] font-bold tracking-[0.08em] uppercase text-[#261f16] font-sans mb-3.5">
              {t.footerOpinionTitle}
            </h4>
            <ul className="space-y-1.5 text-[12px] font-serif text-[#5e4e3a]">
              {links.opinion.map((item, idx) => (
                <li key={idx}>
                  <button
                    onClick={() => onSelectCategory('OPINION')}
                    className="hover:text-[#d97706] hover:underline cursor-pointer transition-colors text-left"
                  >
                    {item}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 4: MOST POPULAR */}
          <div>
            <h4 className="text-[11px] font-bold tracking-[0.08em] uppercase text-[#261f16] font-sans mb-3.5">
              {t.footerPopularTitle}
            </h4>
            <ul className="space-y-1.5 text-[12px] font-serif text-[#5e4e3a]">
              {links.mostPopular.map((item, idx) => (
                <li key={idx}>
                  <button
                    onClick={() => onSelectTag(item)}
                    className="hover:text-[#d97706] hover:underline cursor-pointer transition-colors text-left"
                  >
                    {item}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="w-full border-t border-[#dfd0ba] pt-6 pb-2">
          {/* Social Icons matching original styling: f, g+, mail, twitter */}
          <div className="flex items-center justify-center space-x-4 mb-3 text-[#7a654c]">
            {/* Facebook */}
            <a
              href="#facebook"
              aria-label="Facebook"
              onClick={(e) => e.preventDefault()}
              className="w-6 h-6 flex items-center justify-center font-serif font-bold text-sm hover:text-[#d97706] transition-colors"
            >
              f
            </a>
            {/* Google+ */}
            <a
              href="#googleplus"
              aria-label="Google Plus"
              onClick={(e) => e.preventDefault()}
              className="w-6 h-6 flex items-center justify-center font-sans font-bold text-xs hover:text-[#d97706] transition-colors"
            >
              g+
            </a>
            {/* Mail */}
            <a
              href="#newsletter"
              aria-label="Email"
              onClick={(e) => e.preventDefault()}
              className="w-6 h-6 flex items-center justify-center text-xs hover:text-[#d97706] transition-colors"
            >
              ✉
            </a>
            {/* Twitter */}
            <a
              href="#twitter"
              aria-label="Twitter"
              onClick={(e) => e.preventDefault()}
              className="w-6 h-6 flex items-center justify-center font-serif text-sm hover:text-[#d97706] transition-colors"
            >
              𝕏
            </a>
          </div>

          {/* Copyright */}
          <div className="text-center text-[11px] text-[#8f775c] font-sans">
            {t.footerRights}
          </div>
        </div>
      </div>
    </footer>
  );
};
