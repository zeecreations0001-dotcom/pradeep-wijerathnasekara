import React from 'react';
import { Search, Globe, User, Bookmark, Shield } from 'lucide-react';
import { Language, TRANSLATIONS } from '../data/translations';

interface HeaderProps {
  currentCategory: string;
  language: Language;
  onToggleLanguage: (lang: Language) => void;
  onSelectCategory: (cat: string) => void;
  onOpenSearch: () => void;
  onOpenContact: () => void;
  onOpenShortcodes: () => void;
  onOpenPostTypes: () => void;
  onOpenAdmin?: () => void;
  onOpenReaderAccount?: () => void;
  adminUser?: { name: string; role: string } | null;
  readerUser?: { name: string; email: string; bookmarksCount: number } | null;
}

export const Header: React.FC<HeaderProps> = ({
  currentCategory,
  language,
  onToggleLanguage,
  onSelectCategory,
  onOpenSearch,
  onOpenContact,
  onOpenShortcodes,
  onOpenPostTypes,
  onOpenAdmin,
  onOpenReaderAccount,
  adminUser,
  readerUser,
}) => {
  const t = TRANSLATIONS[language];

  // Live formatted current date based on selected language
  const todayFormatted = new Intl.DateTimeFormat(
    language === 'si' ? 'si-LK' : 'en-US',
    {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      year: 'numeric',
    }
  ).format(new Date());

  const navItems = [
    { label: t.navHome, category: 'ALL' },
    { label: t.navPolitics, category: 'POLITICS' },
    { label: t.navTechnology, category: 'TECHNOLOGY' },
    { label: t.navSports, category: 'SPORTS' },
    { label: t.navFashion, category: 'FASHION' },
    { label: t.navFood, category: 'FOOD' },
    { label: t.navShortcodes, action: onOpenShortcodes },
    { label: t.navPostTypes, action: onOpenPostTypes },
    { label: t.navContacts, action: onOpenContact },
  ];

  return (
    <header className="w-full bg-[#faf6ee] select-none border-b border-[#e2d4be]">
      {/* Top Utility Bar with warm brownish newsprint tint, bright yellow accent badge & Language Switcher */}
      <div className="w-full bg-[#f4ebdc] border-b border-[#e5d8c3]">
        <div className="max-w-[1180px] mx-auto px-4 sm:px-6 h-9 flex items-center justify-between text-[11px] text-[#6b5840] font-sans">
          {/* Current Date & Live Tag */}
          <div className="flex items-center gap-2">
            <span className="bg-[#facc15] text-[#1b1712] font-black text-[9px] tracking-wider px-2 py-0.5 rounded-xs shadow-2xs uppercase">
              {t.dailyEdition}
            </span>
            <span className="text-[#2b2014] tracking-tight font-semibold flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" title="Live update" />
              {todayFormatted}
            </span>
          </div>

          {/* Right utility items: Quick Links + Language Switcher */}
          <div className="flex items-center space-x-3 sm:space-x-4">
            {/* Top Quick Links */}
            <nav className="hidden md:flex items-center space-x-2 text-[11px] tracking-wider text-[#6b5840] uppercase">
              <button
                onClick={() => onSelectCategory('ALL')}
                className="hover:text-[#d97706] transition-colors cursor-pointer"
              >
                {t.navHome}
              </button>
              <span className="text-[#d8c8b0]">|</span>
              <button
                onClick={() => onSelectCategory('POLITICS')}
                className="hover:text-[#d97706] transition-colors cursor-pointer"
              >
                {t.navPolitics}
              </button>
              <span className="text-[#d8c8b0]">|</span>
              <button
                onClick={() => onSelectCategory('OPINION')}
                className="hover:text-[#d97706] transition-colors cursor-pointer"
              >
                {t.navOpinion}
              </button>
              <span className="text-[#d8c8b0]">|</span>
              <button
                onClick={onOpenContact}
                className="hover:text-[#d97706] transition-colors cursor-pointer"
              >
                {t.navContacts}
              </button>
            </nav>

            {/* Reader Account / Saved Stories Button */}
            {onOpenReaderAccount && (
              <button
                type="button"
                onClick={onOpenReaderAccount}
                className="flex items-center gap-1.5 bg-[#f4ebdc] hover:bg-[#ebdcc7] text-[#241c13] font-sans font-bold text-[10px] uppercase tracking-wider px-2 py-1 rounded-xs border border-[#dfcead] transition-colors cursor-pointer"
                title="Reader Account & Saved Stories"
              >
                <User className="w-3 h-3 text-[#d97706]" />
                <span className="hidden sm:inline">
                  {readerUser ? readerUser.name.split(' ')[0] : 'Sign In'}
                </span>
                {readerUser && readerUser.bookmarksCount > 0 && (
                  <span className="bg-[#facc15] text-[#1b1712] px-1 py-0.2 rounded-2xs text-[9px] font-black">
                    {readerUser.bookmarksCount}
                  </span>
                )}
              </button>
            )}

            {/* Newsroom Admin CMS Access Button */}
            {onOpenAdmin && (
              <button
                type="button"
                onClick={onOpenAdmin}
                className="flex items-center gap-1.5 bg-[#1b1712] hover:bg-black text-[#facc15] font-sans font-bold text-[10px] uppercase tracking-wider px-2.5 py-1 rounded-xs shadow-xs transition-colors cursor-pointer border border-[#facc15]/30"
                title="Open Newspaper Editorial Admin Panel (/admin)"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
                <span>Newsroom CMS</span>
                <span className="hidden xl:inline text-[#d4c8a8] font-mono text-[9px]">(/admin)</span>
                {adminUser && (
                  <span className="hidden lg:inline text-stone-300 font-normal">
                    ({adminUser.name})
                  </span>
                )}
              </button>
            )}

            {/* Language Switcher Button Group */}
            <div className="flex items-center gap-1 bg-[#faf6ee] border border-[#dfcead] rounded-xs px-1.5 py-0.5 shadow-2xs">
              <Globe className="w-3 h-3 text-[#d97706] mr-0.5" />
              <button
                onClick={() => onToggleLanguage('en')}
                title="Switch to English"
                className={`px-1.5 py-0.5 text-[10px] font-sans font-bold uppercase transition-all rounded-2xs cursor-pointer ${
                  language === 'en'
                    ? 'bg-[#facc15] text-[#1b1712] shadow-2xs font-black'
                    : 'text-[#6b5840] hover:text-black'
                }`}
              >
                EN
              </button>
              <span className="text-[#d8c8b0] text-[10px]">/</span>
              <button
                onClick={() => onToggleLanguage('si')}
                title="සිංහල භාෂාවට මාරු වන්න"
                className={`px-1.5 py-0.5 text-[10.5px] font-sans font-bold transition-all rounded-2xs cursor-pointer ${
                  language === 'si'
                    ? 'bg-[#facc15] text-[#1b1712] shadow-2xs font-black'
                    : 'text-[#6b5840] hover:text-black'
                }`}
              >
                සිංහල
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Masthead Banner with warm brownish and bright yellow accent */}
      <div className="py-7 sm:py-9 text-center border-b border-[#e8ddcb] bg-[#faf6ee] relative">
        <div className="max-w-[1180px] mx-auto px-4">
          <button
            onClick={() => onSelectCategory('ALL')}
            className="group inline-block text-center cursor-pointer focus:outline-none"
          >
            <h1 className="font-masthead text-4xl sm:text-6xl md:text-[74px] font-black tracking-[-0.03em] leading-none text-[#1b1712] uppercase group-hover:text-[#382b17] transition-colors">
              {t.siteTitle}
            </h1>
          </button>
          <div className="mt-2.5 flex items-center justify-center gap-3">
            <div className="h-[2px] w-14 sm:w-24 bg-gradient-to-r from-transparent via-[#facc15] to-[#d8c5a4]" />
            <span className="text-[10px] sm:text-[11px] font-serif uppercase tracking-[0.2em] text-[#8a7251] font-semibold">
              {t.siteSubtitle}
            </span>
            <div className="h-[2px] w-14 sm:w-24 bg-gradient-to-l from-transparent via-[#facc15] to-[#d8c5a4]" />
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="w-full border-b border-[#dfcead] bg-[#faf6ee]/95 sticky top-0 z-20 shadow-[0_2px_8px_rgba(70,45,15,0.04)] backdrop-blur-xs">
        <div className="max-w-[1180px] mx-auto px-4 sm:px-6 flex items-center justify-between h-11">
          {/* Menu Items */}
          <nav className="flex-1 flex items-center justify-center space-x-3 sm:space-x-5 md:space-x-7 overflow-x-auto scrollbar-none py-1">
            {navItems.map((item) => {
              const isActive =
                item.category && item.category === currentCategory;

              return (
                <button
                  key={item.label}
                  onClick={() => {
                    if (item.action) {
                      item.action();
                    } else if (item.category) {
                      onSelectCategory(item.category);
                    }
                  }}
                  className={`text-[12px] sm:text-[13px] font-bold tracking-[0.06em] uppercase transition-colors whitespace-nowrap relative py-1 ${
                    isActive
                      ? 'text-[#1b1712] font-black after:absolute after:bottom-0 after:left-0 after:right-0 after:h-[3px] after:bg-[#facc15]'
                      : 'text-[#4d3f2f] hover:text-[#d97706]'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Search Trigger */}
          <div className="pl-3 sm:pl-4 flex items-center">
            <button
              onClick={onOpenSearch}
              aria-label={t.searchButton}
              className="p-1.5 text-[#5e4c36] hover:text-black hover:bg-[#facc15]/30 rounded-sm transition-colors cursor-pointer"
              title={t.searchButton}
            >
              <Search className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
