import React, { useState, useEffect } from 'react';
import { ChevronUp, Bookmark, Moon, Sun } from 'lucide-react';

interface FloatingControlsProps {
  onScrollToTop: () => void;
  onOpenAdmin?: () => void;
}

export const FloatingControls: React.FC<FloatingControlsProps> = ({
  onScrollToTop,
  onOpenAdmin,
}) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 200) {
        setVisible(true);
      } else {
        setVisible(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="fixed right-3 bottom-6 z-40 flex flex-col items-end space-y-2">
      {/* Quick CMS Admin Launcher */}
      {onOpenAdmin && (
        <button
          onClick={onOpenAdmin}
          aria-label="Open Newsroom CMS"
          title="Open Newspaper Editorial CMS"
          className="bg-[#1b1712] hover:bg-black text-[#facc15] border border-[#facc15]/40 shadow-lg px-2.5 py-1.5 rounded-xs flex items-center gap-1.5 text-[10px] font-sans font-bold uppercase tracking-wider transition-all cursor-pointer"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
          <span>CMS Admin</span>
        </button>
      )}

      {/* Back to top button */}
      <button
        onClick={onScrollToTop}
        aria-label="Scroll back to top"
        title="Back to Top"
        className={`w-8 h-8 sm:w-9 sm:h-9 bg-[#f4ebdc] hover:bg-[#facc15] text-[#5e4b34] hover:text-[#1b1712] border border-[#dfcead] hover:border-[#eab308] shadow-sm flex items-center justify-center transition-all cursor-pointer rounded-xs ${
          visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2 pointer-events-none'
        }`}
      >
        <ChevronUp className="w-4 h-4 font-bold" />
      </button>
    </div>
  );
};
