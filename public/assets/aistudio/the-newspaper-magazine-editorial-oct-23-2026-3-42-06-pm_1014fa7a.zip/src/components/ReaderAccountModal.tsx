/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { NewsroomStore } from '../services/adminStore';
import { ReaderUser } from '../types/admin';
import { Article } from '../data/newspaperData';
import { Language, TRANSLATIONS } from '../data/translations';
import {
  Bookmark,
  User,
  LogOut,
  Mail,
  Lock,
  ArrowRight,
  Check,
  Clock,
  Sparkles,
  ExternalLink,
  Shield,
  Trash2,
} from 'lucide-react';

interface ReaderAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenArticle: (article: Article) => void;
  onOpenAdmin: () => void;
  language: Language;
}

export const ReaderAccountModal: React.FC<ReaderAccountModalProps> = ({
  isOpen,
  onClose,
  onOpenArticle,
  onOpenAdmin,
  language,
}) => {
  const [currentReader, setCurrentReader] = useState<ReaderUser | null>(NewsroomStore.getCurrentReader());
  const [tab, setTab] = useState<'profile' | 'login' | 'register'>('login');
  
  // Login form
  const [email, setEmail] = useState('reader@herald.org');
  const [password, setPassword] = useState('readerpass');
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  // Register form
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');

  // Bookmarks
  const [bookmarkedArticles, setBookmarkedArticles] = useState<any[]>([]);

  useEffect(() => {
    const unsubscribe = NewsroomStore.subscribe(() => {
      const r = NewsroomStore.getCurrentReader();
      setCurrentReader(r);
      if (r) {
        setBookmarkedArticles(NewsroomStore.getBookmarkedArticles());
      }
    });
    return unsubscribe;
  }, []);

  useEffect(() => {
    const r = NewsroomStore.getCurrentReader();
    setCurrentReader(r);
    if (r) {
      setTab('profile');
      setBookmarkedArticles(NewsroomStore.getBookmarkedArticles());
    } else {
      setTab('login');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    const user = NewsroomStore.loginReader(email, password);
    if (!user) {
      setErrorMessage('Reader account not found with this email. Try reader@herald.org or create an account.');
      return;
    }
    setCurrentReader(user);
    setTab('profile');
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    if (!regName.trim() || !regEmail.trim()) {
      setErrorMessage('Name and email are required.');
      return;
    }
    const res = NewsroomStore.registerReader({
      name: regName.trim(),
      email: regEmail.trim(),
      password: regPassword || 'reader2025',
    });
    if (!res.success) {
      setErrorMessage(res.message || 'Registration failed.');
      return;
    }
    setCurrentReader(res.user || null);
    setTab('profile');
    setSuccessMessage(`Welcome, ${regName}! Your reader account is ready.`);
  };

  const handleLogout = () => {
    NewsroomStore.logoutReader();
    setCurrentReader(null);
    setTab('login');
  };

  const handleRemoveBookmark = (artId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    NewsroomStore.toggleBookmark(artId);
    setBookmarkedArticles(NewsroomStore.getBookmarkedArticles());
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/80 backdrop-blur-xs">
      <div className="relative w-full max-w-lg bg-white rounded-xl shadow-2xl border border-stone-200 overflow-hidden text-stone-900">
        
        {/* Header */}
        <div className="bg-[#1b1712] text-white p-5 border-b border-stone-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="p-1.5 bg-[#facc15] text-[#1b1712] rounded-xs font-bold shadow-xs">
              <User className="w-4 h-4" />
            </span>
            <div>
              <span className="text-[10px] uppercase font-mono text-[#facc15] font-bold tracking-wider">
                Reader Desk
              </span>
              <h2 className="text-lg font-serif font-black text-white">
                {currentReader ? `Reader Profile: ${currentReader.name}` : 'Reader Account'}
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="text-stone-400 hover:text-white text-xs px-2 py-1 rounded bg-stone-800/80 hover:bg-stone-700 cursor-pointer"
          >
            ✕ Close
          </button>
        </div>

        {/* Tab switcher when not logged in */}
        {!currentReader && (
          <div className="flex border-b border-stone-200 bg-stone-100 text-xs font-semibold">
            <button
              type="button"
              onClick={() => {
                setTab('login');
                setErrorMessage('');
              }}
              className={`flex-1 py-2.5 text-center transition cursor-pointer ${
                tab === 'login'
                  ? 'bg-white text-stone-900 border-b-2 border-[#1b1712] font-bold'
                  : 'text-stone-500 hover:text-stone-900'
              }`}
            >
              Reader Sign In
            </button>
            <button
              type="button"
              onClick={() => {
                setTab('register');
                setErrorMessage('');
              }}
              className={`flex-1 py-2.5 text-center transition cursor-pointer ${
                tab === 'register'
                  ? 'bg-white text-stone-900 border-b-2 border-[#1b1712] font-bold'
                  : 'text-stone-500 hover:text-stone-900'
              }`}
            >
              Create Account
            </button>
          </div>
        )}

        {/* Body */}
        <div className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
          {errorMessage && (
            <div className="p-2.5 bg-red-50 text-red-800 border border-red-200 rounded text-xs">
              {errorMessage}
            </div>
          )}
          {successMessage && (
            <div className="p-2.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded text-xs flex items-center gap-1.5">
              <Check className="w-4 h-4 text-emerald-600" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* VIEW: LOGGED IN READER PROFILE & BOOKMARKS */}
          {currentReader && tab === 'profile' && (
            <div className="space-y-5">
              <div className="flex items-center gap-3 p-3 bg-stone-50 rounded-lg border border-stone-200">
                <img
                  src={currentReader.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200'}
                  alt=""
                  className="w-12 h-12 rounded-full object-cover border border-stone-300 shadow-2xs"
                />
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="font-serif font-bold text-stone-900 text-base">{currentReader.name}</h3>
                    <span className="px-2 py-0.5 bg-amber-100 text-amber-900 rounded font-bold text-[10px] uppercase font-mono">
                      Verified Reader
                    </span>
                  </div>
                  <div className="text-xs text-stone-500 font-mono">{currentReader.email}</div>
                  <p className="text-[11px] text-stone-600 mt-1">{currentReader.bio || 'Daily Herald subscriber.'}</p>
                </div>
              </div>

              {/* Saved Stories */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-stone-800 flex items-center gap-1.5">
                    <Bookmark className="w-4 h-4 text-amber-600" />
                    <span>My Saved Articles ({bookmarkedArticles.length})</span>
                  </h4>
                  <span className="text-[11px] text-stone-500">Click to read full story</span>
                </div>

                {bookmarkedArticles.length > 0 ? (
                  <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                    {bookmarkedArticles.map((art) => (
                      <div
                        key={art.id}
                        onClick={() => {
                          onOpenArticle(art);
                          onClose();
                        }}
                        className="p-2.5 bg-stone-50 hover:bg-stone-100 border border-stone-200 rounded-lg flex items-center justify-between gap-3 cursor-pointer transition group"
                      >
                        <div className="flex-1 truncate">
                          <span className="text-[10px] uppercase font-mono text-red-700 font-bold mr-2">
                            {art.sectionId || art.category}
                          </span>
                          <span className="text-xs font-serif font-bold text-stone-900 group-hover:text-red-700 transition">
                            {art.headline || art.title}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={(e) => handleRemoveBookmark(art.id, e)}
                          className="text-stone-400 hover:text-red-600 p-1"
                          title="Remove bookmark"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-6 bg-stone-50 rounded-lg border border-dashed border-stone-300 text-center text-xs text-stone-500">
                    <Bookmark className="w-6 h-6 text-stone-300 mx-auto mb-1" />
                    <p>No saved articles yet.</p>
                    <p className="text-[11px] text-stone-400 mt-0.5">Click the bookmark icon on any article to save it for later.</p>
                  </div>
                )}
              </div>

              {/* Reader actions */}
              <div className="pt-3 border-t border-stone-200 flex items-center justify-between">
                <button
                  type="button"
                  onClick={handleLogout}
                  className="text-xs text-stone-600 hover:text-red-700 flex items-center gap-1 font-medium cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Log Out of Reader Account</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenAdmin();
                  }}
                  className="text-xs text-stone-900 hover:underline flex items-center gap-1 font-semibold cursor-pointer"
                >
                  <Shield className="w-3.5 h-3.5 text-red-600" />
                  <span>Staff / Journalist Desk →</span>
                </button>
              </div>
            </div>
          )}

          {/* VIEW: LOGIN FORM */}
          {!currentReader && tab === 'login' && (
            <form onSubmit={handleLogin} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-stone-700 mb-1">
                  Reader Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="reader@herald.org"
                    className="w-full pl-9 pr-3 py-2 text-xs border border-stone-300 rounded focus:ring-1 focus:ring-stone-800 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-stone-700 mb-1">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs border border-stone-300 rounded focus:ring-1 focus:ring-stone-800 focus:outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-stone-900 hover:bg-black text-[#facc15] text-xs font-semibold uppercase tracking-wider rounded flex items-center justify-center gap-2 shadow-xs transition cursor-pointer"
              >
                Sign In <ArrowRight className="w-4 h-4" />
              </button>

              <div className="pt-2 text-center">
                <span className="text-xs text-stone-500">
                  Are you a journalist or editor?{' '}
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenAdmin();
                    }}
                    className="text-red-700 font-semibold hover:underline"
                  >
                    Go to Newsroom CMS (/admin)
                  </button>
                </span>
              </div>
            </form>
          )}

          {/* VIEW: REGISTER FORM */}
          {!currentReader && tab === 'register' && (
            <form onSubmit={handleRegister} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-stone-700 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  placeholder="e.g. Maya Jin"
                  className="w-full px-3 py-2 text-xs border border-stone-300 rounded focus:ring-1 focus:ring-stone-800 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-stone-700 mb-1">
                  Email Address *
                </label>
                <input
                  type="email"
                  required
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  placeholder="reader@example.com"
                  className="w-full px-3 py-2 text-xs font-mono border border-stone-300 rounded focus:ring-1 focus:ring-stone-800 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-stone-700 mb-1">
                  Password *
                </label>
                <input
                  type="password"
                  required
                  value={regPassword}
                  onChange={(e) => setRegPassword(e.target.value)}
                  placeholder="Create reader password"
                  className="w-full px-3 py-2 text-xs border border-stone-300 rounded focus:ring-1 focus:ring-stone-800 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-stone-900 hover:bg-black text-[#facc15] text-xs font-semibold uppercase tracking-wider rounded flex items-center justify-center gap-2 shadow-xs transition cursor-pointer"
              >
                Create Reader Account <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-2.5 bg-stone-100 border-t border-stone-200 text-center text-[11px] text-stone-500">
          The Daily Herald • Independent Broadsheet Press Trust
        </div>
      </div>
    </div>
  );
};
