# The Newspaper — Digital Newsroom & Editorial CMS

A production-ready digital newsroom content management system and newspaper publishing platform modeled after The New York Times, The Guardian, and BBC News editorial CMS workflows.

Built with **React 18/19**, **Vite**, **Tailwind CSS**, and **Firebase Firestore/Auth** with zero-latency reactive persistence.

---

## Key Features

### 1. Authentication & Role-Based Access Control (RBAC)
- **Super Admin**: Full control over staff, settings, sections, database backup/restore, and all articles.
- **Managing Editor**: Approve and publish articles, curate the above-the-fold hero layout, manage front page section blocks, and moderate reader discourse.
- **Staff Reporter**: Author articles, manage live blog dispatches, submit stories to the review desk, and manage breaking news alerts.
- **Contributor**: Guest draft submission without publishing privileges.
- **One-Click Role Simulation**: Instant switcher in the newsroom header to demo and audit permissions.

### 2. News Article Management
- Rich Text Editor with **TipTap** (headings, pull quotes, lead embeds, inline links, numbered lists).
- **Developing Stories / Live Blog**: Post real-time timestamped dispatches.
- **Editorial Workflow**: `Draft` → `In Review` → `Approved` → `Published` → `Archived`.
- **Bilingual Content**: Native English and Sinhala headline, excerpt, and body fields.
- **Correction Policy Notices**: Append formal corrections to published dispatches.
- **Bulk Actions**: Batch publish, draft, archive, re-assign sections, or delete.

### 3. Breaking News Ticker Manager
- Real-time 1-line flash bulletins.
- Configurable auto-expiry countdown timers (2h, 6h, 12h, 24h).
- Sitewide ticker toggle and style customizer (Continuous Marquee, Static Red Banner, Minimal Newsprint).
- Direct linking from ticker bulletins to full investigative reports.

### 4. Front Page & Layout Editor
- **Above the Fold**: Choose 1 lead story with large imagery and 2–3 secondary stories.
- **Section Blocks**: Reorder homepage blocks, customize article limits, and select presentation styles (Card, Image-First, Grid, Compact List).
- **Right Rail Widgets**: Toggle Most Read Today, Trending Topics, Morning Briefing Signup, Colombo Weather, and Financial Markets.

### 5. Editions & Historical Snapshots
- Bundle daily editions (Morning City Edition, Evening Chronicle, Weekend Special, Print Replica).
- Date-bound historical snapshot viewer simulating published newspaper issues on any given day.

### 6. Site Settings & Brand Customization
- **Typography Pairing**: Google Fonts pairing (Playfair Display, Merriweather, Cinzel, Lora, Newsreader).
- **Brand Colors**: Color pickers for primary slate, accent burgundy, breaking red, and paper tints.
- **Navigation**: Custom primary menu items with mega-menu toggles.
- **SEO & Syndication**: Google News XML sitemap, RSS 2.0 feeds, and robots.txt editor.

---

## Setup & Configuration

### Prerequisites
- Node.js 18+ or Bun
- npm or yarn

### Installation
\`\`\`bash
npm install
npm run dev
\`\`\`
The application will launch on `http://localhost:3000`.

### Connecting Firebase (Firestore + Auth)
1. Create a Firebase project at [https://console.firebase.google.com](https://console.firebase.google.com).
2. Enable **Firestore Database** and **Authentication** (Email/Password).
3. Copy your Web App configuration keys into a `.env` file:
\`\`\`env
VITE_FIREBASE_API_KEY="AIzaSy..."
VITE_FIREBASE_AUTH_DOMAIN="your-app.firebaseapp.com"
VITE_FIREBASE_PROJECT_ID="your-app"
VITE_FIREBASE_STORAGE_BUCKET="your-app.appspot.com"
VITE_FIREBASE_MESSAGING_SENDER_ID="123456789012"
VITE_FIREBASE_APP_ID="1:123456789012:web:abcdef123456"
\`\`\`
4. Deploy security rules:
\`\`\`bash
firebase deploy --only firestore:rules
\`\`\`
(The complete `firestore.rules` file is included in the project root).

---

## Demo Accounts

| Role | Email | Password |
|---|---|---|
| **Super Admin** | `admin@herald.org` | Any string (demo) |
| **Managing Editor** | `editor@herald.org` | Any string (demo) |
| **Staff Reporter** | `reporter@herald.org` | Any string (demo) |
| **Contributor** | `contributor@herald.org` | Any string (demo) |

You can also switch roles with 1 click using the profile menu in the top right corner of the Admin Panel.
