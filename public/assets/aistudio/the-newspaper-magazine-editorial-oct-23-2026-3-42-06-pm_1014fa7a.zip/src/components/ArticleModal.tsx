import React, { useState, useEffect } from 'react';
import { X, Share2, Printer, Check, Bookmark, ThumbsUp, Maximize2 } from 'lucide-react';
import { Article, getLocalizedArticle } from '../data/newspaperData';
import { Language, TRANSLATIONS } from '../data/translations';
import { NewsroomStore } from '../services/adminStore';

interface ArticleModalProps {
  article: Article | null;
  language: Language;
  onClose: () => void;
  onSelectTag?: (tag: string) => void;
  onOpenImageLightbox?: (imageUrl: string, title: string, caption?: string) => void;
}

interface CommentItem {
  id: string;
  author: string;
  date: string;
  text: string;
}

export const ArticleModal: React.FC<ArticleModalProps> = ({
  article: rawArticle,
  language,
  onClose,
  onSelectTag,
  onOpenImageLightbox,
}) => {
  const [fontSize, setFontSize] = useState<'normal' | 'large' | 'xlarge'>('normal');
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(() => rawArticle ? NewsroomStore.isBookmarked(rawArticle.id) : false);
  const [likes, setLikes] = useState(14);
  const [hasLiked, setHasLiked] = useState(false);
  const t = TRANSLATIONS[language];

  useEffect(() => {
    if (rawArticle) {
      setSaved(NewsroomStore.isBookmarked(rawArticle.id));
    }
  }, [rawArticle]);

  const article = rawArticle ? getLocalizedArticle(rawArticle, language) : null;

  const [comments, setComments] = useState<CommentItem[]>([
    {
      id: 'c1',
      author: language === 'si' ? 'මාකස් වැන්ස්' : 'Marcus Vance',
      date: language === 'si' ? '2017 මැයි 14 පෙ.ව. 10:24' : 'MAY 14, 2017 AT 10:24 AM',
      text:
        language === 'si'
          ? 'ඉතාමත් ගැඹුරු හා විමර්ශනාත්මක ලිපියක්. නූතන මාධ්‍ය කලාව තුළ මෙවන් සමබර කතිකාවන් දැකීම සතුටක්.'
          : 'An exceptionally thorough breakdown. The editorial balance here is exemplary and rare in digital media today.',
    },
    {
      id: 'c2',
      author: language === 'si' ? 'ක්ලෙයාර් ඩෙලක්‍රෝයි' : 'Claire Delacroix',
      date: language === 'si' ? '2017 මැයි 14 ප.ව. 2:15' : 'MAY 14, 2017 AT 2:15 PM',
      text:
        language === 'si'
          ? 'ඡායාරූප පෙළගැස්ම අතිශයින් විශිෂ්ටයි. මෙහි සංස්කෘතික පසුබිම පිළිබඳ තවත් විශේෂාංගයක් බලාපොරොත්තු වෙමි.'
          : 'Remarkable photography as well. Would love to read a follow-up feature examining the regional cultural impacts.',
    },
  ]);
  const [newCommentName, setNewCommentName] = useState('');
  const [newCommentText, setNewCommentText] = useState('');

  // Close on Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!article) return null;

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleLike = () => {
    if (!hasLiked) {
      setLikes((prev) => prev + 1);
      setHasLiked(true);
    } else {
      setLikes((prev) => prev - 1);
      setHasLiked(false);
    }
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentName.trim() || !newCommentText.trim()) return;

    const newComment: CommentItem = {
      id: Date.now().toString(),
      author: newCommentName.trim(),
      date: t.justNow,
      text: newCommentText.trim(),
    };

    setComments((prev) => [newComment, ...prev]);
    setNewCommentName('');
    setNewCommentText('');
  };

  const fontSizeClasses = {
    normal: 'text-[16px] leading-[1.8]',
    large: 'text-[18px] leading-[1.85]',
    xlarge: 'text-[20px] leading-[1.9]',
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="article-title"
      className="fixed inset-0 z-50 overflow-y-auto bg-black/65 backdrop-blur-xs flex justify-center p-3 sm:p-6"
    >
      <div
        className="relative bg-[#faf6ee] text-[#241c13] w-full max-w-[840px] my-auto shadow-2xl border border-[#d8c7a8]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Sticky top control header with warm brownish newsprint tint & bright yellow accent */}
        <div className="sticky top-0 z-10 bg-[#f4ebdc]/95 backdrop-blur-xs border-b border-[#dfcead] px-6 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-3 text-xs font-sans text-[#786348]">
            <span className="font-masthead font-extrabold text-[#1b1712] tracking-wider">
              {t.siteTitle}
            </span>
            <span className="text-[#c8b495]">•</span>
            <span className="uppercase tracking-wider font-black text-[#1b1712] bg-[#facc15] px-2 py-0.5 rounded-xs border border-[#eab308]">
              {article.category}
            </span>
          </div>

          <div className="flex items-center space-x-2">
            {/* Font size toggle */}
            <div className="flex items-center border border-[#d8c7a8] rounded-xs text-xs overflow-hidden mr-2 bg-[#faf6ee]">
              <button
                onClick={() => setFontSize('normal')}
                className={`px-2 py-1 ${
                  fontSize === 'normal'
                    ? 'bg-[#facc15] text-black font-extrabold'
                    : 'text-[#614e36] hover:bg-[#efe4cf]'
                }`}
                title="Normal font size"
              >
                A
              </button>
              <button
                onClick={() => setFontSize('large')}
                className={`px-2 py-1 text-sm ${
                  fontSize === 'large'
                    ? 'bg-[#facc15] text-black font-extrabold'
                    : 'text-[#614e36] hover:bg-[#efe4cf]'
                }`}
                title="Large font size"
              >
                A+
              </button>
            </div>

            {/* Share */}
            <button
              onClick={handleShare}
              className="p-1.5 text-[#6b563d] hover:text-[#d97706] hover:bg-[#efe3ce] rounded transition-colors cursor-pointer"
              title={t.shareArticle}
            >
              {copied ? (
                <Check className="w-4 h-4 text-emerald-600" />
              ) : (
                <Share2 className="w-4 h-4" />
              )}
            </button>

            {/* Bookmark */}
            <button
              onClick={() => {
                if (rawArticle) {
                  const newState = NewsroomStore.toggleBookmark(rawArticle.id);
                  setSaved(newState);
                }
              }}
              className="p-1.5 text-[#6b563d] hover:text-[#d97706] hover:bg-[#efe3ce] rounded transition-colors cursor-pointer"
              title={saved ? 'Remove from Saved Articles' : t.bookmarkArticle}
            >
              <Bookmark
                className={`w-4 h-4 ${
                  saved ? 'fill-[#f59e0b] text-[#f59e0b]' : ''
                }`}
              />
            </button>

            {/* Print */}
            <button
              onClick={() => window.print()}
              className="p-1.5 text-[#6b563d] hover:text-[#d97706] hover:bg-[#efe3ce] rounded transition-colors hidden sm:block cursor-pointer"
              title={t.printArticle}
            >
              <Printer className="w-4 h-4" />
            </button>

            {/* Close */}
            <button
              onClick={onClose}
              className="p-1.5 text-[#6b563d] hover:text-[#d97706] hover:bg-[#efe3ce] rounded transition-colors ml-2 cursor-pointer"
              title={`${t.closeModal} (Esc)`}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Article Body */}
        <div className="px-6 sm:px-12 pt-8 pb-12">
          {/* Category & Date */}
          <div className="flex items-center space-x-2 text-[11px] uppercase tracking-wider text-neutral-500 font-sans font-medium mb-3">
            <span className="font-semibold text-neutral-800">
              {article.category}
              {article.categorySecondary ? ` / ${article.categorySecondary}` : ''}
            </span>
            <span>•</span>
            <span>{article.date}</span>
            {article.readTime && (
              <>
                <span>•</span>
                <span>{article.readTime}</span>
              </>
            )}
          </div>

          {/* Headline */}
          <h1
            id="article-title"
            className="font-headline font-bold text-2xl sm:text-4xl leading-[1.25] text-[#111111] mb-5"
          >
            {article.title}
          </h1>

          {/* Byline */}
          <div className="flex items-center justify-between pb-4 mb-6 border-b border-neutral-200 text-xs text-neutral-500 font-sans">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-full bg-neutral-900 text-white font-serif flex items-center justify-center font-bold text-xs uppercase">
                {article.author.slice(0, 2)}
              </div>
              <div>
                <span className="font-semibold text-neutral-900 uppercase tracking-wide">
                  {t.byAuthor} {article.author}
                </span>
                <span className="block text-[11px] text-neutral-400">
                  {language === 'si'
                    ? 'ප්‍රධාන විශේෂාංග ලේඛක'
                    : 'Staff Editorial Correspondent'}
                </span>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <button
                onClick={handleLike}
                className={`flex items-center space-x-1 px-2.5 py-1 rounded text-xs border transition-colors cursor-pointer ${
                  hasLiked
                    ? 'bg-neutral-900 text-white border-neutral-900'
                    : 'border-neutral-300 text-neutral-700 hover:border-neutral-800'
                }`}
              >
                <ThumbsUp className="w-3.5 h-3.5" />
                <span>{likes}</span>
              </button>
            </div>
          </div>

          {/* Lead Image Linked */}
          {article.imageUrl && (
            <figure className="mb-8">
              <a
                href={article.imageUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => {
                  if (onOpenImageLightbox) {
                    e.preventDefault();
                    onOpenImageLightbox(
                      article.imageUrl!,
                      article.title,
                      article.imageCaption
                    );
                  }
                }}
                title={t.viewHighRes}
                className="relative overflow-hidden block bg-neutral-100 aspect-[16/10] group/artImg border border-neutral-200 hover:border-black transition-all cursor-zoom-in"
              >
                <img
                  src={article.imageUrl}
                  alt={article.title}
                  className="w-full h-full object-cover filter contrast-105 group-hover/artImg:scale-102 transition-transform duration-300"
                />
                <div className="absolute bottom-3 right-3 bg-[#facc15] hover:bg-[#ffd200] text-[#1b1712] text-[10px] font-sans font-bold px-2.5 py-1 rounded-xs flex items-center gap-1.5 shadow-sm border border-[#eab308]">
                  <Maximize2 className="w-3 h-3" />
                  <span>{t.viewHighRes}</span>
                </div>
              </a>
              {article.imageCaption && (
                <figcaption className="mt-2 text-xs font-serif italic text-neutral-500 text-center">
                  {article.imageCaption}
                </figcaption>
              )}
            </figure>
          )}

          {/* Paragraphs with drop cap */}
          <div
            className={`font-editorial text-neutral-800 space-y-5 ${fontSizeClasses[fontSize]}`}
          >
            {article.content.map((paragraph, index) => (
              <p
                key={index}
                className={index === 0 && language === 'en' ? 'first-letter-drop' : ''}
              >
                {paragraph}
              </p>
            ))}
          </div>

          {/* Tags */}
          {article.tags && article.tags.length > 0 && (
            <div className="mt-8 pt-6 border-t border-neutral-200">
              <span className="text-xs uppercase tracking-wider font-bold text-neutral-500 font-sans mr-3">
                {t.filedUnder}
              </span>
              <div className="inline-flex flex-wrap gap-2 mt-2 sm:mt-0">
                {article.tags.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => {
                      if (onSelectTag) onSelectTag(tag);
                      onClose();
                    }}
                    className="text-xs font-sans px-2.5 py-1 bg-[#f4ebd9] hover:bg-[#eadbc3] text-[#695126] font-medium rounded-xs transition-colors cursor-pointer"
                  >
                    #{tag}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Comments Section */}
          <section className="mt-12 pt-8 border-t-2 border-[#332616]">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-headline italic text-xl font-bold text-[#221b13]">
                {t.readerDiscussion} ({comments.length})
              </h3>
            </div>

            {/* Comment Form */}
            <form onSubmit={handleAddComment} className="mb-8 p-5 bg-[#f4ebdc] border border-[#dfcead] rounded-xs">
              <h4 className="text-xs uppercase tracking-wider font-bold text-[#5c4625] font-sans mb-3">
                {t.joinConversation}
              </h4>
              <div className="space-y-3">
                <input
                  type="text"
                  placeholder={t.yourNamePlaceholder}
                  value={newCommentName}
                  onChange={(e) => setNewCommentName(e.target.value)}
                  required
                  className="w-full text-xs font-sans px-3 py-2 bg-[#fdfbf7] border border-[#d8c7a8] focus:outline-none focus:border-[#f59e0b] focus:ring-1 focus:ring-[#f59e0b]"
                />
                <textarea
                  rows={3}
                  placeholder={t.commentPlaceholder}
                  value={newCommentText}
                  onChange={(e) => setNewCommentText(e.target.value)}
                  required
                  className="w-full text-xs font-sans px-3 py-2 bg-[#fdfbf7] border border-[#d8c7a8] focus:outline-none focus:border-[#f59e0b] focus:ring-1 focus:ring-[#f59e0b]"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#facc15] hover:bg-[#ffd200] text-[#1b1712] text-[11px] font-black tracking-wider uppercase font-sans cursor-pointer transition-colors shadow-xs border border-[#eab308]"
                >
                  {t.postCommentButton}
                </button>
              </div>
            </form>

            {/* Comment List */}
            <div className="space-y-4">
              {comments.map((c) => (
                <div key={c.id} className="p-3 border-b border-neutral-200 text-xs">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-neutral-900 font-sans uppercase">
                      {c.author}
                    </span>
                    <span className="text-[10px] text-neutral-400 font-mono">
                      {c.date}
                    </span>
                  </div>
                  <p className="font-serif text-neutral-700 leading-relaxed">
                    {c.text}
                  </p>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
