import React from 'react';
import { X, ExternalLink, CheckCircle2, ShieldCheck, Tag } from 'lucide-react';
import { Language } from '../data/translations';

interface AdModalProps {
  isOpen: boolean;
  language?: Language;
  onClose: () => void;
}

export const AdModal: React.FC<AdModalProps> = ({ isOpen, language = 'en', onClose }) => {
  if (!isOpen) return null;

  const isSi = language === 'si';

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="sponsor-modal-title"
      className="fixed inset-0 z-[70] bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="bg-white max-w-md w-full border border-neutral-300 shadow-2xl overflow-hidden relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label={isSi ? 'දැන්වීම වසන්න' : 'Close advertisement'}
          className="absolute top-3 right-3 z-10 bg-white/80 hover:bg-black hover:text-white p-1.5 transition-colors text-neutral-600 cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Ad Image Header */}
        <div className="relative aspect-[16/9] bg-neutral-900 overflow-hidden">
          <img
            src="https://images.unsplash.com/photo-1526738549149-8e07eca6c147?auto=format&fit=crop&w=800&q=80"
            alt="The Newspaper Archive Edition"
            className="w-full h-full object-cover filter grayscale contrast-110 opacity-75"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent flex flex-col justify-end p-5 text-white">
            <span className="text-[10px] font-bold tracking-widest uppercase font-sans text-neutral-300 mb-1 flex items-center gap-1.5">
              <Tag className="w-3 h-3 text-[#facc15]" />
              {isSi ? 'නිල අනුග්‍රාහක සහකරු' : 'Official Sponsor & Partner'}
            </span>
            <h3
              id="sponsor-modal-title"
              className="font-headline font-bold text-xl sm:text-2xl leading-tight"
            >
              {isSi
                ? 'ද නිව්ස්පේපර් ඓතිහාසික ලේඛනාගාරය'
                : 'The Newspaper Heritage Archive'}
            </h3>
          </div>
        </div>

        {/* Ad Body */}
        <div className="p-6 bg-[#faf6ee] text-[#241c13]">
          <div className="text-[11px] font-mono uppercase text-[#967d5c] mb-2">
            {isSi
              ? 'දැන්වීම් ස්ථානගත කිරීම: සිරස් සෘජුකෝණාස්‍රය 240×400'
              : 'Ad Placement: Vertical Rectangle 240×400'}
          </div>

          <p className="font-serif text-sm text-[#4d3d29] leading-relaxed mb-4">
            {isSi
              ? 'වසර 140කට අධික කාලයක් පුරා මුද්‍රිත පුවත්පත්, සම්මානලාභී වාර්තාකරණයන් සහ පැරණි ඡායාරූප එකතුව වෙත අසීමිත ඩිජිටල් ප්‍රවේශය ලබාගන්න.'
              : 'Gain unlimited digital access to over 140 years of front-page journalism, Pulitzer Prize-winning reporting, and high-resolution vintage photo archives.'}
          </p>

          <div className="bg-[#f4ebd9] border border-[#dfcead] p-3 mb-5 space-y-1.5 text-xs text-[#523e25] rounded-xs">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#d97706] shrink-0" />
              <span>
                {isSi
                  ? 'දෛනික මුද්‍රණ සංස්කරණවල පරිපූර්ණ පිටපත්'
                  : 'Full facsimile edition of daily print issues'}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#d97706] shrink-0" />
              <span>
                {isSi
                  ? '1920–2020 ඓතිහාසික ඡායාරූප එකතුව වෙත ප්‍රවේශය'
                  : 'Exclusive access to the 1920–2020 photograph archives'}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#d97706] shrink-0" />
              <span>
                {isSi
                  ? 'හරස්පද සහ විමර්ශනාත්මක විශේෂාංග ඇතුළත්ය'
                  : 'Crossword & historical investigative specials included'}
              </span>
            </div>
          </div>

          {/* Special Offer Code */}
          <div className="border border-dashed border-[#eab308] p-2.5 text-center mb-5 bg-[#fef9c3] rounded-xs">
            <span className="text-[10px] font-sans uppercase tracking-wider text-[#d97706] block font-extrabold">
              {isSi
                ? 'විශේෂ පාඨක දායකත්ව වට්ටම'
                : 'Special Editorial Subscriber Rate'}
            </span>
            <span className="font-mono font-black text-[#713f12] text-sm tracking-widest">
              SAVE50-ARCHIVE
            </span>
          </div>

          {/* Actions */}
          <div className="space-y-2">
            <a
              href="https://archive.org"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3 bg-[#facc15] hover:bg-[#ffd200] text-[#1b1712] text-[11px] font-black tracking-widest uppercase transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm rounded-xs border border-[#eab308]"
            >
              <span>
                {isSi
                  ? 'අනුග්‍රාහක ලේඛනාගාරය වෙත පිවිසෙන්න'
                  : 'Explore Partner Archive Access'}
              </span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>

            <button
              onClick={onClose}
              className="w-full py-2 text-[#786348] hover:text-[#241c13] text-[11px] font-sans uppercase tracking-wider transition-colors cursor-pointer"
            >
              {isSi ? 'මුල් පිටුව වෙත ආපසු යන්න' : 'Return to Front Page'}
            </button>
          </div>

          <div className="mt-4 pt-3 border-t border-[#dfd0ba] flex items-center justify-center gap-1.5 text-[10px] text-[#8f775c] font-sans">
            <ShieldCheck className="w-3 h-3 text-[#d97706]" />
            <span>
              {isSi
                ? 'තහවුරු කළ අනුග්‍රාහකයා • දැන්වීම් අංකය: IAB-240-400-ED'
                : 'Verified Sponsor • Ad ID: IAB-240-400-ED'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
