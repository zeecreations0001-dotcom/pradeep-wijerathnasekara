/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Article,
  FrontPageBlock,
  FrontPageLayout,
  Section,
} from '../../types/admin';
import {
  Layout,
  Sparkles,
  Save,
  Eye,
  ArrowUp,
  ArrowDown,
  Layers,
  CheckCircle,
  Clock,
  Pin,
  Move,
  Grid,
  List,
  Columns,
  Image,
} from 'lucide-react';

interface FrontPageTabProps {
  layout: FrontPageLayout;
  articles: Article[];
  sections: Section[];
  onSaveLayout: (newLayout: FrontPageLayout) => void;
  onPreviewFrontPage: () => void;
}

export const FrontPageTab: React.FC<FrontPageTabProps> = ({
  layout,
  articles,
  sections,
  onSaveLayout,
  onPreviewFrontPage,
}) => {
  // Local working copy of the layout
  const [currentLayout, setCurrentLayout] = useState<FrontPageLayout>(layout);
  const [scheduledDate, setScheduledDate] = useState(layout.scheduledFor || '');
  const [isSavedFeedback, setIsSavedFeedback] = useState(false);

  // Published articles available for selection
  const publishedArticles = articles.filter(
    (a) => a.editorialStatus === 'published' || a.editorialStatus === 'approved'
  );

  const heroMainArticle = articles.find((a) => a.id === currentLayout.heroMainId);
  const heroSecondaryArticles = currentLayout.heroSecondaryIds
    .map((id) => articles.find((a) => a.id === id))
    .filter(Boolean) as Article[];

  // Update hero lead story
  const handleSelectHeroMain = (artId: string) => {
    setCurrentLayout({
      ...currentLayout,
      heroMainId: artId,
    });
  };

  // Update secondary story slot
  const handleSelectSecondary = (index: number, artId: string) => {
    const updated = [...currentLayout.heroSecondaryIds];
    updated[index] = artId;
    setCurrentLayout({
      ...currentLayout,
      heroSecondaryIds: updated,
    });
  };

  // Add secondary slot
  const handleAddSecondarySlot = () => {
    if (currentLayout.heroSecondaryIds.length >= 4) return;
    const available = publishedArticles.find(
      (a) => a.id !== currentLayout.heroMainId && !currentLayout.heroSecondaryIds.includes(a.id)
    );
    if (available) {
      setCurrentLayout({
        ...currentLayout,
        heroSecondaryIds: [...currentLayout.heroSecondaryIds, available.id],
      });
    }
  };

  // Remove secondary slot
  const handleRemoveSecondarySlot = (index: number) => {
    const updated = currentLayout.heroSecondaryIds.filter((_, i) => i !== index);
    setCurrentLayout({
      ...currentLayout,
      heroSecondaryIds: updated,
    });
  };

  // Move block up/down
  const moveBlock = (index: number, direction: 'up' | 'down') => {
    const blocks = [...currentLayout.blocks];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= blocks.length) return;

    const temp = blocks[index];
    blocks[index] = blocks[targetIndex];
    blocks[targetIndex] = temp;

    // renumber orders
    const reordered = blocks.map((b, i) => ({ ...b, order: i + 1 }));
    setCurrentLayout({
      ...currentLayout,
      blocks: reordered,
    });
  };

  // Toggle block visibility
  const toggleBlockVisibility = (blockId: string) => {
    const blocks = currentLayout.blocks.map((b) =>
      b.id === blockId ? { ...b, visible: !b.visible } : b
    );
    setCurrentLayout({ ...currentLayout, blocks });
  };

  // Update block style
  const updateBlockStyle = (blockId: string, style: FrontPageBlock['style']) => {
    const blocks = currentLayout.blocks.map((b) =>
      b.id === blockId ? { ...b, style } : b
    );
    setCurrentLayout({ ...currentLayout, blocks });
  };

  // Toggle widget visibility
  const toggleWidget = (widgetId: string) => {
    const widgets = currentLayout.sidebarWidgets.map((w) =>
      w.id === widgetId ? { ...w, visible: !w.visible } : w
    );
    setCurrentLayout({ ...currentLayout, sidebarWidgets: widgets });
  };

  // Save changes
  const handlePublishLayout = () => {
    const newObj: FrontPageLayout = {
      ...currentLayout,
      publishedAt: new Date().toISOString(),
      scheduledFor: scheduledDate || undefined,
    };
    onSaveLayout(newObj);
    setIsSavedFeedback(true);
    setTimeout(() => setIsSavedFeedback(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Save Actions */}
      <div className="bg-white p-5 rounded-lg border border-stone-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-stone-900 rounded text-white">
              <Layout className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-serif font-bold text-stone-900 tracking-tight">
              Front Page & Layout Editor
            </h1>
          </div>
          <p className="text-xs text-stone-500 mt-1">
            Curate above-the-fold hero coverage, reorder section blocks, and configure reader widgets.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Scheduling */}
          <div className="flex items-center gap-1.5 bg-stone-100 px-3 py-1.5 rounded border border-stone-300 text-xs">
            <Clock className="w-3.5 h-3.5 text-stone-500" />
            <input
              type="datetime-local"
              value={scheduledDate}
              onChange={(e) => setScheduledDate(e.target.value)}
              className="bg-transparent text-xs text-stone-800 focus:outline-none"
              title="Schedule layout change"
            />
          </div>

          <button
            type="button"
            onClick={onPreviewFrontPage}
            className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold rounded flex items-center gap-1.5 border border-stone-300 transition"
          >
            <Eye className="w-4 h-4" /> Live Front Page
          </button>

          <button
            type="button"
            onClick={handlePublishLayout}
            className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-semibold rounded flex items-center gap-1.5 shadow-sm transition"
          >
            <Save className="w-4 h-4" />
            {scheduledDate ? 'Schedule Edition Layout' : 'Publish Layout Now'}
          </button>
        </div>
      </div>

      {isSavedFeedback && (
        <div className="p-3 bg-emerald-50 text-emerald-800 border border-emerald-300 rounded flex items-center gap-2 text-xs font-semibold">
          <CheckCircle className="w-4 h-4 text-emerald-600" />
          Front page layout published successfully. All reader viewports updated!
        </div>
      )}

      {/* SECTION 1: Above-the-Fold Hero Section */}
      <div className="bg-white rounded-lg border border-stone-200 shadow-xs overflow-hidden">
        <div className="px-5 py-3.5 bg-stone-50 border-b border-stone-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-red-600"></span>
            <h2 className="text-xs font-bold uppercase tracking-wider text-stone-800">
              Above The Fold — Hero Area
            </h2>
          </div>
          <span className="text-[11px] text-stone-500 font-serif">
            1 Lead Package + Secondary Stories
          </span>
        </div>

        <div className="p-5 grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Lead Story (2 cols) */}
          <div className="lg:col-span-2 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-stone-700">
                Primary Lead Story (Largest prominence + full width image)
              </label>
              <span className="text-[10px] text-red-600 font-bold uppercase tracking-widest">
                Main Anchor
              </span>
            </div>

            <select
              value={currentLayout.heroMainId}
              onChange={(e) => handleSelectHeroMain(e.target.value)}
              className="w-full px-3 py-2 text-sm font-serif font-bold text-stone-900 bg-stone-50 border border-stone-300 rounded focus:bg-white focus:outline-none"
            >
              {publishedArticles.map((art) => (
                <option key={art.id} value={art.id}>
                  [{art.sectionId.toUpperCase()}] {art.headline}
                </option>
              ))}
            </select>

            {/* Visual preview of chosen main story */}
            {heroMainArticle && (
              <div className="border border-stone-200 rounded p-4 bg-stone-50 flex flex-col sm:flex-row gap-4 items-start">
                <img
                  src={heroMainArticle.featuredImage}
                  alt=""
                  className="w-full sm:w-48 h-32 object-cover rounded shadow-xs"
                />
                <div className="space-y-1 flex-1">
                  <span className="text-[10px] uppercase font-bold text-red-700 tracking-wider">
                    {heroMainArticle.sectionId} • {heroMainArticle.priorityTag}
                  </span>
                  <h3 className="text-base font-serif font-bold text-stone-900 leading-snug">
                    {heroMainArticle.headline}
                  </h3>
                  <p className="text-xs text-stone-600 line-clamp-2">
                    {heroMainArticle.excerpt}
                  </p>
                  <p className="text-[10px] text-stone-400 font-mono">
                    By {heroMainArticle.reporterName} • {heroMainArticle.dateline}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Secondary Stories Slots (1 col) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-stone-700">
                Secondary Stories ({currentLayout.heroSecondaryIds.length} slots)
              </label>
              {currentLayout.heroSecondaryIds.length < 4 && (
                <button
                  type="button"
                  onClick={handleAddSecondarySlot}
                  className="text-xs font-semibold text-red-600 hover:text-red-800"
                >
                  + Add Slot
                </button>
              )}
            </div>

            <div className="space-y-2.5">
              {currentLayout.heroSecondaryIds.map((secId, idx) => {
                const art = articles.find((a) => a.id === secId);
                return (
                  <div key={idx} className="p-2.5 bg-stone-50 rounded border border-stone-200 space-y-1.5">
                    <div className="flex items-center justify-between text-[11px] font-bold text-stone-600">
                      <span>Secondary #{idx + 1}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveSecondarySlot(idx)}
                        className="text-stone-400 hover:text-red-600 text-xs"
                      >
                        ✕
                      </button>
                    </div>
                    <select
                      value={secId}
                      onChange={(e) => handleSelectSecondary(idx, e.target.value)}
                      className="w-full px-2 py-1 text-xs bg-white border border-stone-300 rounded focus:outline-none"
                    >
                      {publishedArticles.map((a) => (
                        <option key={a.id} value={a.id}>
                          [{a.sectionId}] {a.headline}
                        </option>
                      ))}
                    </select>
                    {art && (
                      <p className="text-[11px] font-serif text-stone-800 font-semibold truncate">
                        {art.headline}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 2: Section Blocks Organizer (Draggable / Orderable) */}
      <div className="bg-white rounded-lg border border-stone-200 shadow-xs overflow-hidden">
        <div className="px-5 py-3.5 bg-stone-50 border-b border-stone-200 flex items-center justify-between">
          <div>
            <h2 className="text-xs font-bold uppercase tracking-wider text-stone-800">
              Homepage Section Blocks & Content Flows
            </h2>
            <p className="text-[11px] text-stone-500">
              Drag or use arrows to adjust sequence order; select layout style for each section.
            </p>
          </div>
        </div>

        <div className="divide-y divide-stone-200">
          {currentLayout.blocks.map((block, index) => {
            const section = sections.find((s) => s.id === block.sectionId);

            return (
              <div
                key={block.id}
                className={`p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition ${
                  !block.visible ? 'bg-stone-50/70 opacity-60' : 'hover:bg-stone-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  {/* Sequence arrow buttons */}
                  <div className="flex flex-col gap-0.5">
                    <button
                      type="button"
                      disabled={index === 0}
                      onClick={() => moveBlock(index, 'up')}
                      className="p-1 hover:bg-stone-200 rounded text-stone-500 disabled:opacity-20"
                    >
                      <ArrowUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      disabled={index === currentLayout.blocks.length - 1}
                      onClick={() => moveBlock(index, 'down')}
                      className="p-1 hover:bg-stone-200 rounded text-stone-500 disabled:opacity-20"
                    >
                      <ArrowDown className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <span
                        className="w-2.5 h-2.5 rounded-full"
                        style={{ backgroundColor: section?.color || '#333' }}
                      />
                      <span className="text-sm font-serif font-bold text-stone-900">
                        {block.title || section?.name}
                      </span>
                      <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 bg-stone-100 rounded text-stone-600">
                        {block.sectionId}
                      </span>
                    </div>
                    <div className="text-xs text-stone-500 mt-0.5 flex items-center gap-3">
                      <span>Article count: <strong>{block.articleCount}</strong></span>
                      <span>Mode: <strong>{block.autoPopulateLatest ? 'Auto-populate latest' : 'Manual curated'}</strong></span>
                    </div>
                  </div>
                </div>

                {/* Block Controls: Style & Visibility */}
                <div className="flex items-center gap-3 self-end sm:self-center">
                  <div className="flex items-center gap-1 bg-stone-100 p-1 rounded border border-stone-200 text-xs">
                    <button
                      type="button"
                      onClick={() => updateBlockStyle(block.id, 'card')}
                      className={`px-2 py-1 rounded flex items-center gap-1 ${
                        block.style === 'card' ? 'bg-white shadow-xs font-bold text-stone-900' : 'text-stone-500'
                      }`}
                      title="Card Layout"
                    >
                      <Columns className="w-3.5 h-3.5" /> Cards
                    </button>
                    <button
                      type="button"
                      onClick={() => updateBlockStyle(block.id, 'image-first')}
                      className={`px-2 py-1 rounded flex items-center gap-1 ${
                        block.style === 'image-first' ? 'bg-white shadow-xs font-bold text-stone-900' : 'text-stone-500'
                      }`}
                      title="Image First"
                    >
                      <Image className="w-3.5 h-3.5" /> Image-First
                    </button>
                    <button
                      type="button"
                      onClick={() => updateBlockStyle(block.id, 'grid')}
                      className={`px-2 py-1 rounded flex items-center gap-1 ${
                        block.style === 'grid' ? 'bg-white shadow-xs font-bold text-stone-900' : 'text-stone-500'
                      }`}
                      title="Grid"
                    >
                      <Grid className="w-3.5 h-3.5" /> Grid
                    </button>
                    <button
                      type="button"
                      onClick={() => updateBlockStyle(block.id, 'list')}
                      className={`px-2 py-1 rounded flex items-center gap-1 ${
                        block.style === 'list' ? 'bg-white shadow-xs font-bold text-stone-900' : 'text-stone-500'
                      }`}
                      title="List"
                    >
                      <List className="w-3.5 h-3.5" /> Compact
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => toggleBlockVisibility(block.id)}
                    className={`px-3 py-1.5 rounded text-xs font-semibold border transition ${
                      block.visible
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                        : 'bg-stone-100 text-stone-500 border-stone-300'
                    }`}
                  >
                    {block.visible ? 'Visible' : 'Hidden'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* SECTION 3: Sidebar Widgets Organizer */}
      <div className="bg-white rounded-lg border border-stone-200 shadow-xs overflow-hidden">
        <div className="px-5 py-3.5 bg-stone-50 border-b border-stone-200">
          <h2 className="text-xs font-bold uppercase tracking-wider text-stone-800">
            Right Rail / Sidebar Editorial Widgets
          </h2>
          <p className="text-[11px] text-stone-500">
            Enable or disable contextual widgets on the front page desktop sidebar.
          </p>
        </div>

        <div className="p-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {currentLayout.sidebarWidgets.map((widget) => (
            <div
              key={widget.id}
              onClick={() => toggleWidget(widget.id)}
              className={`p-3 rounded-lg border cursor-pointer transition flex items-center justify-between ${
                widget.visible
                  ? 'bg-stone-50 border-stone-300 hover:border-red-600'
                  : 'bg-stone-100/50 border-dashed border-stone-300 opacity-60'
              }`}
            >
              <div>
                <div className="text-xs font-bold text-stone-800">{widget.label}</div>
                <div className="text-[10px] text-stone-400 font-mono capitalize">
                  {widget.type.replace('_', ' ')}
                </div>
              </div>
              <div
                className={`w-4 h-4 rounded-full border flex items-center justify-center text-[10px] ${
                  widget.visible
                    ? 'bg-red-600 border-red-600 text-white font-bold'
                    : 'border-stone-400'
                }`}
              >
                {widget.visible ? '✓' : ''}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
