import React, { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import {
  LATEST_ARTICLES_TITLES,
  RECOMMENDED_BOOKS,
  TOP_SEARCHES_TAGS,
  Article,
  getLocalizedArticle,
  getLocalizedBook,
} from '../data/newspaperData';
import {
  Language,
  TRANSLATIONS,
  LATEST_ARTICLES_TITLES_SI,
} from '../data/translations';

interface LeftSidebarProps {
  popularArticles: Article[];
  language: Language;
  onSelectArticle: (article: Article) => void;
  onSelectTitle: (title: string) => void;
  onSelectTag: (tag: string) => void;
  onOpenAd: () => void;
  onOpenImage?: (imageUrl: string, title: string, caption?: string) => void;
}

export const LeftSidebar: React.FC<LeftSidebarProps> = ({
  popularArticles,
  language,
  onSelectArticle,
  onSelectTitle,
  onSelectTag,
  onOpenAd,
  onOpenImage,
}) => {
  const [recommendedIndex, setRecommendedIndex] = useState(0);
  const t = TRANSLATIONS[language];

  const rawBook = RECOMMENDED_BOOKS[recommendedIndex];
  const currentBook = getLocalizedBook(rawBook, language);

  const latestTitles =
    language === 'si' ? LATEST_ARTICLES_TITLES_SI : LATEST_ARTICLES_TITLES;

  const handlePrevBook = () => {
    setRecommendedIndex((prev) =>
      prev === 0 ? RECOMMENDED_BOOKS.length - 1 : prev - 1
    );
  };

  const handleNextBook = () => {
    setRecommendedIndex((prev) =>
      prev === RECOMMENDED_BOOKS.length - 1 ? 0 : prev + 1
    );
  };

  return (
    <aside className="w-full flex flex-col space-y-7 pb-6 select-none border-b lg:border-b-0 lg:border-r border-[#e5d8c3] lg:pr-6">
      {/* Latest Articles */}
      <section>
        <div className="border-b border-[#dfd0ba] pb-1 mb-3">
          <h3 className="text-[12px] font-bold tracking-[0.06em] text-[#241c13] uppercase font-sans flex items-center justify-between">
            <span>{t.latestArticlesTitle}</span>
            <span className="w-2.5 h-2.5 rounded-full bg-[#facc15] shadow-[0_0_8px_#fde047] animate-pulse" />
          </h3>
        </div>

        <ul className="space-y-2.5 text-[13px] leading-[1.35] text-[#332a1e]">
          {latestTitles.map((title, idx) => (
            <li key={idx} className="flex items-start group">
              <span className="text-[#eab308] mr-2 text-[12px] leading-tight select-none font-bold">
                •
              </span>
              <button
                onClick={() => onSelectTitle(title)}
                className="text-left font-serif text-[12.5px] leading-snug text-[#332a1e] hover:text-[#b48012] hover:underline underline-offset-2 transition-colors cursor-pointer"
              >
                {title}
              </button>
            </li>
          ))}
        </ul>
      </section>

      {/* Recommended Carousel */}
      <section className="pt-2 border-t border-[#e5d8c3]">
        <div className="flex items-center justify-between pb-2 mb-3 border-b border-[#dfd0ba]">
          <h3 className="text-[12px] font-bold tracking-[0.06em] text-[#241c13] uppercase font-sans">
            {t.recommendedTitle}
          </h3>
          <div className="flex items-center space-x-1 text-[#8f7450]">
            <button
              onClick={handlePrevBook}
              aria-label="Previous recommended item"
              className="hover:text-[#d97706] transition-colors p-0.5 cursor-pointer"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <span className="text-[10px] text-[#cfbe9f]">/</span>
            <button
              onClick={handleNextBook}
              aria-label="Next recommended item"
              className="hover:text-[#d97706] transition-colors p-0.5 cursor-pointer"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="group">
          {/* Linked Image */}
          <div className="relative overflow-hidden block bg-[#f4ebdc] aspect-[4/3] mb-2.5 border border-[#dfd0ba] hover:border-[#eab308] transition-colors">
            <a
              href={`#recommended-${currentBook.id}`}
              onClick={(e) => {
                e.preventDefault();
                onSelectTitle(currentBook.title);
              }}
              title={`View story: ${currentBook.title}`}
              className="block w-full h-full cursor-pointer"
            >
              <img
                src={currentBook.imageUrl}
                alt={currentBook.title}
                onError={(e) => {
                  e.currentTarget.src =
                    'https://images.unsplash.com/photo-1545235617-9465d2a55698?auto=format&fit=crop&w=400&q=80';
                }}
                className="w-full h-full object-cover filter grayscale contrast-110 group-hover:filter-none group-hover:scale-103 transition-all duration-300"
              />
            </a>
            <div className="absolute top-2 right-2 flex items-center space-x-1">
              {onOpenImage && (
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    onOpenImage(currentBook.imageUrl, currentBook.title);
                  }}
                  title={t.zoomImage}
                  className="bg-black/80 hover:bg-black text-white text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded-xs transition-colors cursor-pointer"
                >
                  {t.zoomImage}
                </button>
              )}
              <span
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  onSelectTitle(currentBook.title);
                }}
                className="bg-[#facc15] hover:bg-[#ffd200] text-black text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-xs transition-colors cursor-pointer shadow-xs border border-[#eab308]"
              >
                {t.viewStory}
              </span>
            </div>
          </div>
          <h4
            onClick={() => onSelectTitle(currentBook.title)}
            className="font-serif font-bold text-[13.5px] leading-tight text-neutral-900 hover:text-[#d97706] hover:underline underline-offset-2 cursor-pointer transition-colors"
          >
            {currentBook.title}
          </h4>
        </div>
      </section>

      {/* Most Popular */}
      <section className="pt-2 border-t border-[#e5d8c3]">
        <div className="border-b border-[#dfd0ba] pb-1 mb-4">
          <h3 className="text-[12px] font-bold tracking-[0.06em] text-[#241c13] uppercase font-sans">
            {t.mostPopularTitle}
          </h3>
        </div>

        <div className="space-y-4">
          {popularArticles.slice(0, 5).map((rawArticle, idx) => {
            const article = getLocalizedArticle(rawArticle, language);
            const rank = idx + 1;
            return (
              <div
                key={article.id}
                onClick={() => onSelectArticle(article)}
                className="flex items-start gap-3 group cursor-pointer"
              >
                {/* Large Serif Rank Number with vivid bright golden-yellow accent */}
                <div className="font-serif italic font-black text-3xl sm:text-4xl text-[#d97706] group-hover:text-[#b45309] leading-none w-7 shrink-0 pt-0.5 select-none transition-colors drop-shadow-[0_1px_1px_rgba(250,204,21,0.3)]">
                  {rank}
                </div>
                {/* Title */}
                <h4 className="font-serif text-[13px] leading-[1.3] text-[#261f17] group-hover:text-[#d97706] group-hover:underline underline-offset-2 transition-colors">
                  {article.title}
                </h4>
              </div>
            );
          })}
        </div>
      </section>

      {/* Advertising Box - Warm Newsprint Parchment with High-Impact Bright Yellow CTA */}
      <section className="pt-2 border-t border-[#e5d8c3]">
        <div className="flex items-center justify-between border-b border-[#dfd0ba] pb-1 mb-3">
          <h3 className="text-[11px] font-bold tracking-[0.06em] text-[#8a7251] uppercase font-sans">
            {t.advertisingTitle}
          </h3>
          <span className="text-[9px] font-mono uppercase tracking-wider text-[#d97706] font-extrabold bg-[#fef08a] px-2 py-0.5 rounded-xs border border-[#fde047]">
            {t.sponsoredBadge}
          </span>
        </div>

        <a
          href="#sponsor-campaign"
          onClick={(e) => {
            e.preventDefault();
            onOpenAd();
          }}
          title={t.visitAdvertiser}
          className="group relative block w-full aspect-[240/360] max-w-[240px] mx-auto bg-[#f4ebdc] hover:bg-[#efe3d0] border border-dashed border-[#cdba99] hover:border-[#eab308] transition-all p-4 text-center cursor-pointer shadow-xs hover:shadow-md overflow-hidden"
        >
          {/* Subtle archival watermark sponsor image */}
          <img
            src="https://images.unsplash.com/photo-1526738549149-8e07eca6c147?auto=format&fit=crop&w=400&q=80"
            alt="Sponsored advertisement link"
            className="absolute inset-0 w-full h-full object-cover filter grayscale contrast-125 sepia-30 opacity-20 group-hover:opacity-35 group-hover:scale-105 transition-all duration-300 pointer-events-none"
          />

          <div className="relative z-10 h-full flex flex-col items-center justify-center">
            <span className="text-[15px] font-bold text-[#7a6549] group-hover:text-[#261f17] tracking-[0.1em] uppercase font-sans leading-tight transition-colors">
              {t.adVertical}
            </span>
            <span className="text-[15px] font-bold text-[#7a6549] group-hover:text-[#261f17] tracking-[0.1em] uppercase font-sans leading-tight mt-1 transition-colors">
              {t.adRectangle}
            </span>
            <span className="text-[12px] font-medium text-[#998160] group-hover:text-[#d97706] tracking-wider font-mono mt-2 transition-colors">
              {t.adDimensions}
            </span>

            {/* Click to open ad CTA badge in bright yellow */}
            <div className="mt-5 px-3 py-1.5 bg-[#facc15] hover:bg-[#ffd200] text-[10px] font-black tracking-widest uppercase text-[#1b1712] transition-all inline-flex items-center gap-1 shadow-sm rounded-xs border border-[#eab308]">
              <span>{t.visitAdvertiser}</span>
              <span className="text-xs font-black">↗</span>
            </div>
          </div>
        </a>
      </section>

      {/* Top Searches Tag Cloud */}
      <section className="pt-2 border-t border-[#e5d8c3]">
        <div className="border-b border-[#dfd0ba] pb-1 mb-3">
          <h3 className="text-[12px] font-bold tracking-[0.06em] text-[#241c13] uppercase font-sans">
            {t.topSearchesTitle}
          </h3>
        </div>

        <div className="flex flex-wrap items-baseline gap-x-2.5 gap-y-2 leading-relaxed">
          {TOP_SEARCHES_TAGS.map((tag, idx) => {
            const isFeaturedTag = idx === 1 || idx === 3 || idx === 7;
            const displayText =
              language === 'si' && tag.textSi ? tag.textSi : tag.text;
            return (
              <button
                key={idx}
                onClick={() => onSelectTag(tag.text)}
                className={`${tag.style} ${
                  isFeaturedTag
                    ? 'bg-[#fef9c3] border border-[#fde047] px-1.5 py-0.5 rounded-xs text-[#713f12] hover:bg-[#fde047]'
                    : 'hover:text-[#d97706]'
                } hover:underline cursor-pointer transition-colors`}
              >
                {displayText}
              </button>
            );
          })}
        </div>
      </section>
    </aside>
  );
};
