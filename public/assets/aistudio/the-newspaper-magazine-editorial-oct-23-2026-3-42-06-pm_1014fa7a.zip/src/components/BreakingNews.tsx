import React from 'react';
import { MessageSquare } from 'lucide-react';
import { Article, getLocalizedArticle } from '../data/newspaperData';
import { Language, TRANSLATIONS } from '../data/translations';

interface BreakingNewsProps {
  articles: Article[];
  language: Language;
  onSelectArticle: (article: Article) => void;
  onOpenLightbox?: (imageUrl: string, title: string, caption?: string) => void;
}

export const BreakingNews: React.FC<BreakingNewsProps> = ({
  articles,
  language,
  onSelectArticle,
  onOpenLightbox,
}) => {
  const t = TRANSLATIONS[language];
  const rawHero = articles.find((a) => a.isHero) || articles[0];
  const heroArticle = rawHero ? getLocalizedArticle(rawHero, language) : null;

  const rawOtherBreaking = articles.filter(
    (a) => a.isBreaking && a.id !== rawHero?.id
  );

  return (
    <div className="w-full pb-6 lg:px-6 border-b lg:border-b-0 lg:border-r border-[#e5d8c3]">
      {/* Column Header */}
      <div className="border-b border-[#dfd0ba] pb-2 mb-4 flex items-center justify-between">
        <h2 className="font-headline italic text-2xl sm:text-[26px] font-bold text-[#221b13] leading-none flex items-center gap-2.5">
          <span>{t.breakingNewsTitle}</span>
          <span className="bg-[#facc15] text-[#1b1712] font-black text-[10px] tracking-widest px-2 py-0.5 rounded-xs uppercase shadow-xs">
            {t.liveBadge}
          </span>
        </h2>
      </div>

      {/* Hero Article */}
      {heroArticle && (
        <article className="mb-7 group">
          {heroArticle.imageUrl && (
            <div className="relative overflow-hidden block bg-[#f4ebdc] aspect-[16/10] mb-3.5 border border-[#dfd0ba] hover:border-[#eab308] transition-all group/img">
              <a
                href={`#article-${heroArticle.id}`}
                onClick={(e) => {
                  e.preventDefault();
                  onSelectArticle(heroArticle);
                }}
                title={heroArticle.title}
                className="block w-full h-full cursor-pointer"
              >
                <img
                  src={heroArticle.imageUrl}
                  alt={heroArticle.title}
                  onError={(e) => {
                    e.currentTarget.src =
                      'https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1200&q=80';
                  }}
                  className="w-full h-full object-cover filter grayscale contrast-110 sepia-20 group-hover:filter-none group-hover/img:scale-102 transition-all duration-300"
                />
              </a>

              {/* Direct Action Badges */}
              <div className="absolute top-2.5 right-2.5 flex items-center space-x-1.5">
                {onOpenLightbox && (
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      onOpenLightbox(
                        heroArticle.imageUrl!,
                        heroArticle.title,
                        heroArticle.imageCaption
                      );
                    }}
                    title={t.zoomImage}
                    className="bg-[#241c13]/85 hover:bg-black text-white text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-xs transition-colors opacity-90 group-hover/img:opacity-100 cursor-pointer shadow-xs"
                  >
                    {t.zoomImage}
                  </button>
                )}
                <span
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    onSelectArticle(heroArticle);
                  }}
                  className="bg-[#facc15] hover:bg-[#ffd200] text-[#1b1712] text-[9.5px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-xs transition-all opacity-95 group-hover/img:opacity-100 flex items-center gap-1 cursor-pointer shadow-xs border border-[#eab308]"
                >
                  {t.viewStory}
                </span>
              </div>
            </div>
          )}

          {/* Meta line */}
          <div className="flex flex-wrap items-center gap-x-2 text-[10.5px] uppercase tracking-wider text-[#8a7251] font-sans mb-2 font-medium">
            <span>{heroArticle.date}</span>
            <span className="text-[#d8c8b0]">/</span>
            <span className="text-[#d97706] font-bold bg-[#fef08a]/60 px-1 rounded-xs">
              {heroArticle.category}
              {heroArticle.categorySecondary ? `, ${heroArticle.categorySecondary}` : ''}
            </span>
            <span className="text-[#d8c8b0]">/</span>
            <span>
              {t.byAuthor} {heroArticle.author}
            </span>
            <span className="text-[#d8c8b0]">/</span>
            <span className="inline-flex items-center gap-1">
              <MessageSquare className="w-2.5 h-2.5 text-[#d97706]" />
              {heroArticle.commentsCount}
            </span>
          </div>

          {/* Headline */}
          <h3
            onClick={() => onSelectArticle(heroArticle)}
            className="font-headline font-bold text-[22px] sm:text-[25px] leading-[1.25] text-[#221b13] mb-2.5 cursor-pointer group-hover:text-[#d97706] transition-colors"
          >
            {heroArticle.title}
          </h3>

          {/* Excerpt */}
          <p className="font-serif text-[13.5px] leading-relaxed text-[#4d4030] mb-3.5">
            {heroArticle.excerpt}
          </p>

          {/* Read more button */}
          <button
            onClick={() => onSelectArticle(heroArticle)}
            className="text-[11px] font-bold tracking-[0.08em] uppercase text-[#d97706] border-b-2 border-[#facc15] pb-0.5 hover:text-[#b45309] hover:border-[#f59e0b] transition-colors cursor-pointer"
          >
            {t.readMore}
          </button>
        </article>
      )}

      {/* Other Breaking News Articles */}
      <div className="space-y-6">
        {rawOtherBreaking.map((rawArticle) => {
          const article = getLocalizedArticle(rawArticle, language);
          return (
            <article
              key={article.id}
              className="pt-6 border-t border-[#e5d8c3] group"
            >
              {/* Meta line */}
              <div className="flex flex-wrap items-center gap-x-2 text-[10.5px] uppercase tracking-wider text-[#8a7251] font-sans mb-1.5 font-medium">
                <span>{article.date}</span>
                <span className="text-[#d8c8b0]">/</span>
                <span className="text-[#d97706] font-bold bg-[#fef08a]/60 px-1 rounded-xs">
                  {article.category}
                  {article.categorySecondary ? `, ${article.categorySecondary}` : ''}
                </span>
                <span className="text-[#d8c8b0]">/</span>
                <span>
                  {t.byAuthor} {article.author}
                </span>
                <span className="text-[#d8c8b0]">/</span>
                <span className="inline-flex items-center gap-1">
                  <MessageSquare className="w-2.5 h-2.5 text-[#d97706]" />
                  {article.commentsCount}
                </span>
              </div>

              {/* Headline */}
              <h3
                onClick={() => onSelectArticle(article)}
                className="font-headline font-bold text-[18px] sm:text-[20px] leading-[1.25] text-[#221b13] mb-2 cursor-pointer group-hover:text-[#d97706] transition-colors"
              >
                {article.title}
              </h3>

              {/* Excerpt */}
              <p className="font-serif text-[13px] leading-relaxed text-[#4d4030] mb-3">
                {article.excerpt}
              </p>

              {/* Read more */}
              <button
                onClick={() => onSelectArticle(article)}
                className="text-[11px] font-bold tracking-[0.08em] uppercase text-[#d97706] border-b border-[#fcd34d] pb-0.5 hover:text-[#b45309] hover:border-[#f59e0b] transition-colors cursor-pointer"
              >
                {t.readMore}
              </button>
            </article>
          );
        })}
      </div>
    </div>
  );
};
